from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponseForbidden
from django.core.mail import send_mail
from django.conf import settings
import google.generativeai as genai
import openai
import os
from dotenv import load_dotenv
load_dotenv()

import firebase_admin
from firebase_admin import credentials, firestore, auth

# Initialize Firebase Admin once
if not firebase_admin._apps:
    cred = credentials.Certificate("firebase_key.json")
    firebase_admin.initialize_app(cred)

db = firestore.client()

def get_user_preferences(uid):
    try:
        doc = db.collection("users").document(uid).get()
        if doc.exists:
            return doc.to_dict()
    except Exception as e:
        print("Error fetching preferences:", e)
    return {
        "ai_name": "Your AI",
        "tone": "neutral"
    }

@csrf_exempt
def home(request):
    return render(request, "myapp/index.html")

@csrf_exempt
def generate_page(request):
    history = []
    response_text = ""
    prompt = ""

    if request.method == "POST":
        prompt = request.POST.get("prompt", "")
        model_choice = request.POST.get("model", "gemini-1.5-flash")
        file_data = request.FILES.get("file_input")
        uid = request.POST.get("firebase_uid", "").strip()
        is_guest = not uid

        if is_guest:
            uid = "guest_user"

        prefs = get_user_preferences(uid)

        mentor_prompt = f"""
You are an AI mentor named {prefs['ai_name']}.
Speak in a {prefs['tone']} tone.
Your job is to help users grow, not give answers.
Avoid direct answers to academic questions.
Be like a smart, helpful older sibling or friend.
        """

        if prompt:
            banned = ["what's the answer", "just tell me", "give me answer", "solve this", "cheat", "hypothetically"]
            if any(b in prompt.lower() for b in banned):
                prompt = "The user is trying to get a direct answer. Help them think critically instead."

            # ========== Gemini ==========
            if model_choice.startswith("gemini"):
                genai.configure(api_key=os.getenv("GEMINI_API_KEY"))
                model = genai.GenerativeModel("gemini-1.5-flash")

                if file_data:
                    import tempfile
                    with tempfile.NamedTemporaryFile(delete=False) as temp_file:
                        for chunk in file_data.chunks():
                            temp_file.write(chunk)
                        gemini_response = model.generate_content([
                            mentor_prompt,
                            prompt,
                            {
                                "mime_type": file_data.content_type,
                                "data": open(temp_file.name, "rb").read()
                            }
                        ])
                else:
                    gemini_response = model.generate_content([
                        mentor_prompt,
                        prompt
                    ])

                response_text = gemini_response.text

            # ========== OpenAI ==========
            elif model_choice.startswith("openai"):
                openai.api_key = os.getenv("OPENAI_API_KEY")
                full_prompt = mentor_prompt + "\nUser: " + prompt
                completion = openai.ChatCompletion.create(
                    model="gpt-4",
                    messages=[
                        {"role": "system", "content": mentor_prompt},
                        {"role": "user", "content": prompt}
                    ]
                )
                response_text = completion.choices[0].message['content']

        if not is_guest:
            history_ref = db.collection("users").document(uid).collection("chat_history")
            history_ref.add({
                "prompt": prompt,
                "response": response_text,
                "timestamp": firestore.SERVER_TIMESTAMP
            })

        return render(request, "myapp/generate.html", {
            "response": response_text,
            "prompt": prompt
        })

    return render(request, "myapp/generate.html")

@csrf_exempt
def onboarding_page(request):
    if request.method == "POST":
        uid = request.POST.get("firebase_uid", "").strip()
        ai_name = request.POST.get("ai_name", "Your AI")
        tone = request.POST.get("tone", "neutral")

        if uid:
            db.collection("users").document(uid).set({
                "ai_name": ai_name,
                "tone": tone
            }, merge=True)

        return render(request, "myapp/generate.html")

    return render(request, "myapp/onboarding.html")

@csrf_exempt
def password_reset_request(request):
    if request.method == "POST":
        email = request.POST.get("email", "").strip()
        if not email:
            return render(request, "myapp/password_reset.html", {"error": "Email is required."})

        try:
            reset_link = auth.generate_password_reset_link(email)
            send_mail(
                subject="Password Reset Request",
                message=f"Click the link to reset your password:\n{reset_link}",
                from_email=settings.DEFAULT_FROM_EMAIL,
                recipient_list=[email],
                fail_silently=False,
            )
            return render(request, "myapp/password_reset.html", {"message": "Reset email sent."})
        except Exception as e:
            print("Error:", e)
            return render(request, "myapp/password_reset.html", {"error": "Failed to send reset email."})

    return render(request, "myapp/password_reset.html")

def chat_history(request):
    return render(request, "myapp/chat_history.html")

def login_page(request):
    return render(request, "myapp/login.html")

def signup_page(request):
    if request.method == "POST":
        return render(request, "myapp/onboarding.html")
    return render(request, "myapp/signup.html")

def feedback_page(request):
    return render(request, "myapp/feedback.html")

def logout_view(request):
    request.session.flush()
    return render(request, "myapp/index.html")
