// // Add your Firebase config below
// const firebaseConfig = {
//   apiKey: "YOUR-KEY",
//   authDomain: "YOUR.firebaseapp.com",
//   projectId: "YOUR-ID",
//   storageBucket: "YOUR.appspot.com",
//   messagingSenderId: "YOUR-SENDER-ID",
//   appId: "YOUR-APP-ID"
// };

// firebase.initializeApp(firebaseConfig);
